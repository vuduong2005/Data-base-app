package com.example.data1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "contact_database.db";
    private static final String TABLE_NAME = "contact_details";

    private static final String ID_COLUMN_NAME = "person_id";
    private static final String NAME_COLUMN_NAME = "name";
    private static final String DOB_COLUMN_NAME = "dob";
    private static final String EMAIL_COLUMN_NAME = "email";
    private static final String PROFILE_PIC_COLUMN_NAME = "profile_pic";

    private static final String DATABASE_CREATE_QUERY =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    ID_COLUMN_NAME + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    NAME_COLUMN_NAME + " TEXT, " +
                    DOB_COLUMN_NAME + " TEXT, " +
                    EMAIL_COLUMN_NAME + " TEXT, " +
                    PROFILE_PIC_COLUMN_NAME + " TEXT );";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void close() {
        super.close();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DATABASE_CREATE_QUERY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        Log.w(this.getClass().getName(),
                TABLE_NAME + " upgraded to version " + newVersion + ". Old data lost.");
        onCreate(db);
    }


    public long insertDetails(String name, String dob, String email, String profilePicUri) {
        ContentValues rowValues = new ContentValues();
        rowValues.put(NAME_COLUMN_NAME, name);
        rowValues.put(DOB_COLUMN_NAME, dob);
        rowValues.put(EMAIL_COLUMN_NAME, email);
        rowValues.put(PROFILE_PIC_COLUMN_NAME, profilePicUri);


        return this.getWritableDatabase().insertOrThrow(TABLE_NAME, null, rowValues);
    }




    public Cursor getLatestDetailsCursor() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_NAME,
                null,
                null, null, null, null,
                ID_COLUMN_NAME + " DESC",
                "1");
    }

    public String getDetails() {
        Cursor results = null;
        StringBuilder resultText = new StringBuilder("--- No contact details found. ---");

        try {
            SQLiteDatabase database = this.getReadableDatabase();
            results = database.query(TABLE_NAME,
                    new String[]{ID_COLUMN_NAME, NAME_COLUMN_NAME, DOB_COLUMN_NAME, EMAIL_COLUMN_NAME},
                    null, null, null, null, NAME_COLUMN_NAME);

            if (results.moveToFirst()) {
                resultText.setLength(0);
                do {
                    int id = results.getInt(0);
                    String name = results.getString(1);
                    String dob = results.getString(2);
                    String email = results.getString(3);

                    resultText.append("ID: ").append(id).append("\n")
                            .append("Name: ").append(name).append("\n")
                            .append("Date of Birth: ").append(dob).append("\n")
                            .append("Email: ").append(email).append("\n")
                            .append("-----------------------------\n");
                } while (results.moveToNext());
            }

        } finally {
            if (results != null) {
                results.close();
            }
        }
        return resultText.toString();
    }
}