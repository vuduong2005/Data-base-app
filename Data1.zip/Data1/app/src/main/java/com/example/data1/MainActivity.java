package com.example.data1;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private ImageView profileImageView;
    private String profilePicUri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // 1. Initialize Image Views and Button
        profileImageView = findViewById(R.id.profileImageView);
        Button selectImageButton = findViewById(R.id.selectImageButton);

        // Listener to launch image selection
        selectImageButton.setOnClickListener(v -> openImageChooser());

        // 2. Save button
        Button saveBtn = findViewById(R.id.button);
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveDetails();
            }
        });

        // 3. View info button
        Button viewInfoBtn = findViewById(R.id.viewInfoBtn);
        viewInfoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                startActivity(intent);
            }
        });
    }

    // --- Image Selection Methods ---

    private void openImageChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");

        // Explicitly list accepted types for better compatibility (PNG and JPEG)
        String[] mimeTypes = {"image/jpeg", "image/png"};
        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);

        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) { // <-- FIX: Removed duplicate 'int'
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {

            // Store the URI (the file path string)
            profilePicUri = data.getData().toString();

            try {
                // Convert URI to Bitmap and display it for preview
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), data.getData());
                profileImageView.setImageBitmap(bitmap);

            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to load image for preview.", Toast.LENGTH_SHORT).show();
                profilePicUri = null;
            }
        }
    }

    // --- Save Details Method ---

    private void saveDetails() {
        DatabaseHelper dbHelper = null;
        long personId = -1;

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());

            EditText nameTxt = findViewById(R.id.editTextText);
            EditText dobTxt = findViewById(R.id.editTextText2);
            EditText emailTxt = findViewById(R.id.editTextText3);

            String name = nameTxt.getText().toString();
            String dob = dobTxt.getText().toString();
            String email = emailTxt.getText().toString();

            personId = dbHelper.insertDetails(name, dob, email, profilePicUri);

        } catch (Exception e) {
            Toast.makeText(this, "Save Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        } finally {
            if (dbHelper != null) {
                dbHelper.close();
            }
        }

        Toast.makeText(this, "Person created with ID: " + personId,
                Toast.LENGTH_LONG).show();
    }
}