package com.example.data1;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

public class DetailsActivity extends AppCompatActivity {

    private static final String NAME_COLUMN_NAME = "name";
    private static final String DOB_COLUMN_NAME = "dob";
    private static final String EMAIL_COLUMN_NAME = "email";
    private static final String PROFILE_PIC_COLUMN_NAME = "profile_pic";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_info);

        DatabaseHelper dbHelper = null;
        Cursor cursor = null;
        TextView detailsTxt = findViewById(R.id.detailsText);
        ImageView profilePicView = findViewById(R.id.detailsProfilePic);

        String details = "No contact details saved yet or failed to load.";

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            cursor = dbHelper.getLatestDetailsCursor();

            if (cursor != null && cursor.moveToFirst()) {

                int nameIndex = cursor.getColumnIndex(NAME_COLUMN_NAME);
                int dobIndex = cursor.getColumnIndex(DOB_COLUMN_NAME);
                int emailIndex = cursor.getColumnIndex(EMAIL_COLUMN_NAME);
                int imageUriIndex = cursor.getColumnIndex(PROFILE_PIC_COLUMN_NAME); // Added

                if (nameIndex != -1 && dobIndex != -1 && emailIndex != -1) {

                    details = "Name: " + cursor.getString(nameIndex) + "\n"
                            + "Date of Birth: " + cursor.getString(dobIndex) + "\n"
                            + "Email: " + cursor.getString(emailIndex) + "\n";
                }

                // 2. Retrieve and display the image using the URI
                if (imageUriIndex != -1 && !cursor.isNull(imageUriIndex)) {
                    String imageUriString = cursor.getString(imageUriIndex);

                    if (imageUriString != null) {
                        try {
                            Uri imageUri = Uri.parse(imageUriString);

                            // Use ContentResolver to load the image from the URI
                            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                            profilePicView.setImageBitmap(bitmap);

                        } catch (IOException e) {
                            Log.e("DetailsActivity", "Failed to load image from URI: ", e);
                        }
                    }
                }

            }

        } catch (Exception e) {
            details = "Error loading data: " + e.getMessage();
            Log.e("DetailsActivity", "Database error: ", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (dbHelper != null) {
                dbHelper.close();
            }
        }

        detailsTxt.setText(details);
    }
}